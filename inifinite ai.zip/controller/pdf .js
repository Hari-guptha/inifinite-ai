const route=require("express").Router()
route.get()

module.exports=route