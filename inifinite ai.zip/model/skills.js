/* const mongoose=require("mongoose")
const schema=mongoose.Schema
const skill_schema=new schema({
    
    skill_1:{
        type:String,
        required:false
    },
    skill_2:{
        type:String,
        required:false
    },
    skill_3:{
        type:String,
        required:false
    },
    skill_4:{
        type:String,
        required:false
    },
    skill_5:{
        type:String,
        required:false
    }
},{ versionKey: false})
const skill=mongoose.model("skills",skill_schema)
module.exports=skill */