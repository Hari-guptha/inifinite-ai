#include<stdio.h>
#include<math.h>
void main()
{
    int i,j;
    for(i=1;i<6;i++)
    {
        for(j=i;j<6;j++)
        {
            printf("*");
        }
        printf("\n");
    }
}